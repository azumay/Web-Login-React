import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Servicio from "../components/Servicios/Servicios";
import { Link } from "react-router-dom";
import SignUpForm from "../components/Form/SignUpForm";

export default function Inici(props) {
 
  return (

    <div className="container">
      <div className="row">
      <h1 className="mb-5">Formulario de registro</h1>
   
      <Servicio img="signup.png" titulo="Sign up" />
      <SignUpForm/>
      <Link to="/">Volver</Link>
      
    </div>
    </div>
  );
}