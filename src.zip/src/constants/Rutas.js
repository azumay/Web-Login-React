
// Rutes de l'aplicació
export const urlsApp = {
    login:"/Login",
    signup:"/SignUp",
    inici:"/",
    

}